import { useState, useEffect } from 'react';
import { AuthProvider } from '@/context/AuthContext';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import HomePage from '@/pages/HomePage';
import LibraryPage from '@/pages/LibraryPage';
import ContributionPage from '@/pages/ContributionPage';
import AccessPage from '@/pages/AccessPage';
import ResourcesPage from '@/pages/ResourcesPage';
import ProfilePage from '@/pages/ProfilePage';
import AuthPage from '@/pages/AuthPage';
import { type Page } from '@/types/navigation';

function AppContent() {
  const [currentPage, setCurrentPage] = useState<Page>('accueil');

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [currentPage]);

  const renderPage = () => {
    switch (currentPage) {
      case 'accueil':
        return <HomePage onNavigate={handleNavigate} />;
      case 'bibliotheque':
        return <LibraryPage />;
      case 'contribution':
        return <ContributionPage onNavigate={handleNavigate} />;
      case 'acces':
        return <AccessPage onNavigate={handleNavigate} />;
      case 'ressources':
        return <ResourcesPage onNavigate={handleNavigate} />;
      case 'profil':
        return <ProfilePage onNavigate={handleNavigate} />;
      case 'connexion':
        return <AuthPage mode="signin" onNavigate={handleNavigate} />;
      case 'inscription':
        return <AuthPage mode="signup" onNavigate={handleNavigate} />;
      case 'mot-de-passe-oublie':
        return <AuthPage mode="forgot" onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50">
      <Navbar currentPage={currentPage} onNavigate={handleNavigate} />
      <main className="flex-1">{renderPage()}</main>
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
