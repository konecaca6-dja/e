export type Page =
  | 'accueil'
  | 'bibliotheque'
  | 'contribution'
  | 'acces'
  | 'ressources'
  | 'profil'
  | 'connexion'
  | 'inscription'
  | 'mot-de-passe-oublie';

export const NAV_ITEMS: { id: Page; label: string }[] = [
  { id: 'accueil', label: 'Accueil' },
  { id: 'bibliotheque', label: 'Bibliothèque' },
  { id: 'contribution', label: 'Contribution' },
  { id: 'acces', label: 'Accès' },
  { id: 'ressources', label: 'Ressources gratuites' },
];

export type UserRole = 'visiteur' | 'utilisateur' | 'contributeur' | 'moderateur' | 'administrateur';

export const ROLE_LABELS: Record<UserRole, string> = {
  visiteur: 'Visiteur',
  utilisateur: 'Utilisateur',
  contributeur: 'Contributeur',
  moderateur: 'Modérateur',
  administrateur: 'Administrateur',
};

export const ROLE_BADGE_COLORS: Record<UserRole, string> = {
  visiteur: 'bg-stone-100 text-stone-600',
  utilisateur: 'bg-blue-100 text-blue-700',
  contributeur: 'bg-emerald-100 text-emerald-700',
  moderateur: 'bg-amber-100 text-amber-700',
  administrateur: 'bg-rose-100 text-rose-700',
};
