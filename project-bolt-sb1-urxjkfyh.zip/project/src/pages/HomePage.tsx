import {
  BookOpen,
  Users,
  Search,
  Sparkles,
  Upload,
  Lock,
  Globe,
  ArrowRight,
  CheckCircle2,
  Library,
  Heart,
} from 'lucide-react';
import { type Page } from '@/types/navigation';

interface HomePageProps {
  onNavigate: (page: Page) => void;
}

const features = [
  {
    icon: Search,
    title: 'Recherche intelligente',
    description: 'Trouvez instantanément parmi des milliers de documents grâce à une recherche sémantique avancée.',
  },
  {
    icon: Users,
    title: 'Collaboratif',
    description: 'Contribuez, annotez et partagez. Le savoir se construit ensemble, par et pour la communauté.',
  },
  {
    icon: Sparkles,
    title: 'Organisation automatique',
    description: 'Catégorisation et indexation intelligentes des documents pour une navigation fluide et intuitive.',
  },
  {
    icon: Upload,
    title: 'Contribution simplifiée',
    description: 'Importez vos documents en quelques clics. Partagez vos trouvailles avec la communauté.',
  },
  {
    icon: Globe,
    title: 'Accès universel',
    description: 'Une plateforme ouverte, accessible partout, à tout moment, sur tous vos appareils.',
  },
  {
    icon: Lock,
    title: 'Accès sécurisé',
    description: 'Vos documents protégés, vos contributions valorisées. Confidentialité et sécurité garanties.',
  },
];

const steps = [
  { icon: BookOpen, title: 'Explorez', description: 'Parcourez la bibliothèque et découvrez des milliers de documents.' },
  { icon: Upload, title: 'Contribuez', description: 'Ajoutez vos propres documents et enrichissez la collection.' },
  { icon: Heart, title: 'Partagez', description: 'Échangez avec la communauté et faites vivre le savoir.' },
];

export default function HomePage({ onNavigate }: HomePageProps) {
  return (
    <div className="animate-fade-in">
      {/* Hero */}
      <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-stone-50 via-white to-stone-100" />
        <div className="absolute top-20 right-0 w-72 h-72 bg-stone-200/40 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-stone-300/30 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-stone-900/5 border border-stone-300 mb-6 animate-fade-up">
              <Sparkles className="w-4 h-4 text-stone-600" />
              <span className="text-sm font-medium text-stone-600">Bibliothèque numérique collaborative</span>
            </div>

            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-stone-900 leading-tight animate-fade-up" style={{ animationDelay: '0.1s' }}>
              Le savoir documentaire,
              <br />
              <span className="italic text-stone-600">réinventé ensemble</span>
            </h1>

            <p className="mt-6 text-lg text-stone-600 leading-relaxed max-w-2xl mx-auto animate-fade-up" style={{ animationDelay: '0.2s' }}>
              Archivo est une bibliothèque numérique intelligente et collaborative.
              Explorez, contribuez et partagez des documents dans un espace pensé
              pour faire vivre la connaissance.
            </p>

            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-up" style={{ animationDelay: '0.3s' }}>
              <button
                onClick={() => onNavigate('inscription')}
                className="w-full sm:w-auto px-8 py-3.5 text-base font-semibold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-all duration-200 shadow-lg hover:shadow-xl hover:-translate-y-0.5"
              >
                Créer un compte
              </button>
              <button
                onClick={() => onNavigate('connexion')}
                className="w-full sm:w-auto px-8 py-3.5 text-base font-semibold text-stone-900 bg-white border border-stone-300 rounded-xl hover:bg-stone-50 transition-all duration-200 shadow-sm hover:shadow-md hover:-translate-y-0.5"
              >
                Se connecter
              </button>
            </div>
          </div>

          {/* Hero illustration */}
          <div className="mt-16 lg:mt-24 relative animate-scale-in" style={{ animationDelay: '0.4s' }}>
            <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-2xl border border-stone-200 p-6 lg:p-8">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {steps.map((step, i) => (
                  <div key={i} className="flex flex-col items-center text-center p-6 rounded-xl bg-stone-50 hover:bg-stone-100 transition-colors">
                    <div className="w-12 h-12 rounded-xl bg-stone-900 text-white flex items-center justify-center mb-4">
                      <step.icon className="w-6 h-6" />
                    </div>
                    <h3 className="font-serif text-lg font-semibold text-stone-900 mb-1">{step.title}</h3>
                    <p className="text-sm text-stone-600">{step.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Concept */}
      <section className="py-20 lg:py-28 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-sm font-semibold text-stone-500 uppercase tracking-wider">Le concept</span>
              <h2 className="mt-3 font-serif text-3xl lg:text-4xl font-semibold text-stone-900 leading-tight">
                Une bibliothèque qui apprend
                <br />et grandit avec vous
              </h2>
              <p className="mt-6 text-lg text-stone-600 leading-relaxed">
                Archivo n'est pas une simple bibliothèque en ligne. C'est un écosystème
                documentaire où chaque utilisateur peut découvrir des ressources, en
                ajouter de nouvelles, et participer à l'enrichissement collectif du savoir.
              </p>
              <p className="mt-4 text-lg text-stone-600 leading-relaxed">
                Grâce à des outils intelligents de recherche et de catégorisation,
                trouvez exactement ce que vous cherchez en un instant.
              </p>

              <ul className="mt-8 space-y-3">
                {[
                  'Catalogue enrichi et continuellement mis à jour',
                  'Système de tags et catégories intelligent',
                  'Espace personnel pour vos favoris et contributions',
                  'Accès gratuit à des milliers de ressources',
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-stone-700 flex-shrink-0 mt-0.5" />
                    <span className="text-stone-700">{item}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => onNavigate('bibliotheque')}
                className="mt-8 inline-flex items-center gap-2 text-base font-semibold text-stone-900 hover:gap-3 transition-all"
              >
                Explorer la bibliothèque
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>

            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-br from-stone-200 to-stone-300 rounded-3xl blur-2xl opacity-30" />
              <div className="relative bg-white rounded-2xl shadow-xl border border-stone-200 p-8">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-10 h-10 rounded-lg bg-stone-900 text-white flex items-center justify-center">
                    <Library className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-serif text-lg font-semibold text-stone-900">Catalogue Archivo</h3>
                    <p className="text-xs text-stone-500">Aperçu des collections</p>
                  </div>
                </div>
                <div className="space-y-3">
                  {[
                    { cat: 'Histoire', count: '1,240 documents', color: 'bg-amber-100 text-amber-800' },
                    { cat: 'Sciences', count: '980 documents', color: 'bg-blue-100 text-blue-800' },
                    { cat: 'Littérature', count: '2,100 documents', color: 'bg-emerald-100 text-emerald-800' },
                    { cat: 'Droit', count: '560 documents', color: 'bg-rose-100 text-rose-800' },
                    { cat: 'Philosophie', count: '720 documents', color: 'bg-violet-100 text-violet-800' },
                  ].map((row, i) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg hover:bg-stone-50 transition-colors">
                      <div className="flex items-center gap-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${row.color}`}>{row.cat}</span>
                      </div>
                      <span className="text-sm text-stone-500">{row.count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 lg:py-28 bg-stone-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-sm font-semibold text-stone-500 uppercase tracking-wider">Fonctionnalités</span>
            <h2 className="mt-3 font-serif text-3xl lg:text-4xl font-semibold text-stone-900">
              Tout ce qu'il faut pour explorer le savoir
            </h2>
            <p className="mt-4 text-lg text-stone-600">
              Des outils pensés pour la découverte, la contribution et le partage documentaire.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <div
                key={i}
                className="group bg-white rounded-2xl p-8 border border-stone-200 hover:border-stone-300 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <div className="w-12 h-12 rounded-xl bg-stone-100 group-hover:bg-stone-900 group-hover:text-white text-stone-700 flex items-center justify-center mb-5 transition-all duration-300">
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="font-serif text-xl font-semibold text-stone-900 mb-3">{feature.title}</h3>
                <p className="text-sm text-stone-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 lg:py-28 bg-stone-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="font-serif text-3xl lg:text-4xl font-semibold text-white leading-tight">
            Prêt à explorer le savoir collectif ?
          </h2>
          <p className="mt-4 text-lg text-stone-400 max-w-xl mx-auto">
            Rejoignez la communauté Archivo et accédez à un univers documentaire
            en constante évolution.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => onNavigate('inscription')}
              className="w-full sm:w-auto px-8 py-3.5 text-base font-semibold text-stone-900 bg-white rounded-xl hover:bg-stone-100 transition-all duration-200 shadow-lg hover:-translate-y-0.5"
            >
              Créer un compte
            </button>
            <button
              onClick={() => onNavigate('ressources')}
              className="w-full sm:w-auto px-8 py-3.5 text-base font-semibold text-white border border-white/30 rounded-xl hover:bg-white/10 transition-all duration-200"
            >
              Découvrir les ressources gratuites
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
