import { useState } from 'react';
import { Upload, CheckCircle2, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { type Page } from '@/types/navigation';

const CATEGORIES = ['Histoire', 'Sciences', 'Littérature', 'Droit', 'Philosophie', 'Art', 'Autre'];

interface ContributionPageProps {
  onNavigate: (page: Page) => void;
}

export default function ContributionPage({ onNavigate }: ContributionPageProps) {
  const { user } = useAuth();
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [isFree, setIsFree] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="min-h-screen pt-32 pb-20 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 rounded-2xl bg-stone-100 flex items-center justify-center mx-auto mb-6">
            <Upload className="w-8 h-8 text-stone-400" />
          </div>
          <h2 className="font-serif text-2xl font-semibold text-stone-900 mb-3">Connexion requise</h2>
          <p className="text-stone-600 mb-6">
            Connectez-vous pour contribuer à la bibliothèque et partager vos documents.
          </p>
          <button
            onClick={() => onNavigate('connexion')}
            className="px-6 py-3 text-sm font-semibold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-colors"
          >
            Se connecter
          </button>
        </div>
      </div>
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) {
      setError('Le titre est obligatoire.');
      return;
    }
    setSubmitting(true);
    setError(null);

    const { error: insertError } = await supabase.from('documents').insert({
      title: title.trim(),
      author: author.trim() || null,
      description: description.trim() || null,
      category: category || null,
      is_free: isFree,
      status: 'published',
    });

    setSubmitting(false);

    if (insertError) {
      setError(insertError.message);
      return;
    }

    setSuccess(true);
    setTitle('');
    setAuthor('');
    setDescription('');
    setCategory('');
    setIsFree(true);

    setTimeout(() => setSuccess(false), 4000);
  }

  return (
    <div className="min-h-screen pt-24 pb-20 animate-fade-in">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="pt-8 pb-10">
          <h1 className="font-serif text-3xl lg:text-4xl font-semibold text-stone-900">Contribution</h1>
          <p className="mt-3 text-stone-600 text-lg">
            Partagez un document avec la communauté Archivo.
          </p>
        </div>

        {success && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-3 animate-fade-up">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            <p className="text-sm text-emerald-800">Votre document a été publié avec succès dans la bibliothèque.</p>
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-3 animate-fade-up">
            <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
            <p className="text-sm text-rose-800">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-stone-200 p-6 lg:p-8 space-y-6">
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-2">
              Titre du document <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ex: Introduction à la philosophie moderne"
              className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-stone-700 mb-2">Auteur</label>
            <input
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="Ex: Jean Dupont"
              className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-stone-700 mb-2">Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              placeholder="Résumé ou description du contenu du document..."
              className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-stone-700 mb-2">Catégorie</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
            >
              <option value="">Sélectionner une catégorie</option>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-xl bg-stone-50 border border-stone-200">
            <button
              type="button"
              onClick={() => setIsFree(!isFree)}
              className={`relative w-12 h-6 rounded-full transition-colors ${isFree ? 'bg-stone-900' : 'bg-stone-300'}`}
            >
              <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${isFree ? 'translate-x-6' : ''}`} />
            </button>
            <div>
              <p className="text-sm font-medium text-stone-900">Accès gratuit</p>
              <p className="text-xs text-stone-500">Rendre ce document accessible gratuitement à tous</p>
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={submitting}
              className="px-8 py-3.5 text-base font-semibold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {submitting ? 'Publication...' : 'Publier le document'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
