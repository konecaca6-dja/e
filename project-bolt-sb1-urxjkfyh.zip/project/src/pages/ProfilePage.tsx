import { useState, useEffect, useRef } from 'react';
import {
  User,
  Save,
  LogOut,
  BookOpen,
  Edit2,
  CheckCircle2,
  AlertCircle,
  Lock,
  KeyRound,
  Monitor,
  Shield,
  X,
  Camera,
  Heart,
  History,
  FileText,
  Mail,
  Globe,
  Trash2,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { type Page, type UserRole, ROLE_LABELS, ROLE_BADGE_COLORS } from '@/types/navigation';

interface ProfilePageProps {
  onNavigate: (page: Page) => void;
}

interface UserDoc {
  id: string;
  title: string;
  category: string | null;
  is_free: boolean;
  created_at: string;
}

interface FavoriteDoc {
  id: string;
  document_id: string;
  documents: {
    id: string;
    title: string;
    category: string | null;
    author: string | null;
  }[];
}

interface HistoryEntry {
  id: string;
  document_id: string;
  consulted_at: string;
  documents: {
    id: string;
    title: string;
    category: string | null;
  }[];
}

const LANGUAGES = [
  { code: 'fr', label: 'Français' },
  { code: 'en', label: 'English' },
  { code: 'es', label: 'Español' },
  { code: 'de', label: 'Deutsch' },
];

type TabId = 'informations' | 'favoris' | 'historique' | 'contributions' | 'securite';

export default function ProfilePage({ onNavigate }: ProfilePageProps) {
  const { user, profile, signOut, signOutAllSessions, changePassword, updateEmail, refreshProfile, loading } = useAuth();
  const [editing, setEditing] = useState(false);
  const [username, setUsername] = useState(profile?.username ?? '');
  const [firstName, setFirstName] = useState(profile?.first_name ?? '');
  const [lastName, setLastName] = useState(profile?.last_name ?? '');
  const [bio, setBio] = useState(profile?.bio ?? '');
  const [preferredLanguage, setPreferredLanguage] = useState(profile?.preferred_language ?? 'fr');
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<TabId>('informations');

  // Data
  const [docs, setDocs] = useState<UserDoc[]>([]);
  const [favorites, setFavorites] = useState<FavoriteDoc[]>([]);
  const [history, setHistory] = useState<HistoryEntry[]>([]);

  // Avatar upload
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [avatarUploading, setAvatarUploading] = useState(false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(profile?.avatar_url ?? null);

  // Password change modal
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);
  const [passwordMsg, setPasswordMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Email change modal
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [newEmail, setNewEmail] = useState('');
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailMsg, setEmailMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Sign out all modal
  const [showSignOutAllModal, setShowSignOutAllModal] = useState(false);
  const [signOutAllLoading, setSignOutAllLoading] = useState(false);

  useEffect(() => {
    if (profile) {
      setUsername(profile.username);
      setFirstName(profile.first_name ?? '');
      setLastName(profile.last_name ?? '');
      setBio(profile.bio ?? '');
      setPreferredLanguage(profile.preferred_language ?? 'fr');
      setAvatarUrl(profile.avatar_url ?? null);
    }
  }, [profile]);

  useEffect(() => {
    if (!user) return;

    supabase
      .from('documents')
      .select('id, title, category, is_free, created_at')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        if (data) setDocs(data as UserDoc[]);
      });

    supabase
      .from('favorites')
      .select('id, document_id, documents(id, title, category, author)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .then(({ data }) => {
        if (data) setFavorites(data as FavoriteDoc[]);
      });

    supabase
      .from('consultation_history')
      .select('id, document_id, consulted_at, documents(id, title, category)')
      .eq('user_id', user.id)
      .order('consulted_at', { ascending: false })
      .limit(50)
      .then(({ data }) => {
        if (data) setHistory(data as HistoryEntry[]);
      });
  }, [user]);

  // Load signed avatar URL when avatar_url changes
  useEffect(() => {
    if (!profile?.avatar_url) {
      setAvatarUrl(null);
      return;
    }
    const path = profile.avatar_url;
    supabase.storage.from('avatars').createSignedUrl(path, 3600).then(({ data }) => {
      if (data?.signedUrl) setAvatarUrl(data.signedUrl);
    });
  }, [profile?.avatar_url]);

  if (loading) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-stone-300 border-t-stone-900 rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen pt-32 pb-20 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 rounded-2xl bg-stone-100 flex items-center justify-center mx-auto mb-6">
            <User className="w-8 h-8 text-stone-400" />
          </div>
          <h2 className="font-serif text-2xl font-semibold text-stone-900 mb-3">Connexion requise</h2>
          <p className="text-stone-600 mb-6">Connectez-vous pour accéder à votre profil.</p>
          <button
            onClick={() => onNavigate('connexion')}
            className="px-6 py-3 text-sm font-semibold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-colors"
          >
            Se connecter
          </button>
        </div>
      </div>
    );
  }

  async function handleSave() {
    setSaving(true);
    setError(null);
    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        username,
        first_name: firstName || null,
        last_name: lastName || null,
        full_name: [firstName, lastName].filter(Boolean).join(' ') || null,
        bio: bio || null,
        preferred_language: preferredLanguage,
      })
      .eq('id', user!.id);
    setSaving(false);
    if (updateError) {
      console.error('Profile update failed', updateError);
      setError('Impossible de mettre à jour le profil. Vérifiez que le nom d\'utilisateur n\'est pas déjà pris.');
      return;
    }
    await refreshProfile();
    setSavedMsg(true);
    setEditing(false);
    setTimeout(() => setSavedMsg(false), 3000);
  }

  async function handleAvatarUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 2 * 1024 * 1024) {
      setError('L\'image ne doit pas dépasser 2 Mo.');
      return;
    }
    if (!file.type.startsWith('image/')) {
      setError('Veuillez sélectionner un fichier image.');
      return;
    }

    setAvatarUploading(true);
    setError(null);

    const ext = file.name.split('.').pop() ?? 'jpg';
    const path = `${user.id}/avatar.${ext}`;

    const { error: uploadError } = await supabase.storage
      .from('avatars')
      .upload(path, file, { upsert: true });

    if (uploadError) {
      console.error('Avatar upload failed', uploadError);
      setError('Erreur lors du téléchargement de la photo. Veuillez réessayer.');
      setAvatarUploading(false);
      return;
    }

    const { error: updateError } = await supabase
      .from('profiles')
      .update({ avatar_url: path })
      .eq('id', user.id);

    if (updateError) {
      console.error('Avatar URL update failed', updateError);
      setError('Photo téléchargée mais erreur de sauvegarde.');
      setAvatarUploading(false);
      return;
    }

    await refreshProfile();
    setAvatarUploading(false);
  }

  async function handleSignOut() {
    await signOut();
    onNavigate('accueil');
  }

  async function handleSignOutAll() {
    setSignOutAllLoading(true);
    const { error: signOutError } = await signOutAllSessions();
    setSignOutAllLoading(false);
    setShowSignOutAllModal(false);
    if (signOutError) {
      setError(signOutError);
      return;
    }
    onNavigate('accueil');
  }

  async function handleChangePassword() {
    setPasswordMsg(null);
    if (newPassword.length < 6) {
      setPasswordMsg({ type: 'error', text: 'Le mot de passe doit contenir au moins 6 caractères.' });
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setPasswordMsg({ type: 'error', text: 'Les mots de passe ne correspondent pas.' });
      return;
    }
    setPasswordLoading(true);
    const { error: pwdError } = await changePassword(newPassword);
    setPasswordLoading(false);
    if (pwdError) {
      setPasswordMsg({ type: 'error', text: pwdError });
      return;
    }
    setPasswordMsg({ type: 'success', text: 'Mot de passe modifié avec succès.' });
    setNewPassword('');
    setConfirmNewPassword('');
    setTimeout(() => {
      setShowPasswordModal(false);
      setPasswordMsg(null);
    }, 2000);
  }

  async function handleChangeEmail() {
    setEmailMsg(null);
    if (!newEmail.trim() || !newEmail.includes('@')) {
      setEmailMsg({ type: 'error', text: 'Veuillez saisir une adresse e-mail valide.' });
      return;
    }
    setEmailLoading(true);
    const { error: emailError } = await updateEmail(newEmail.trim());
    setEmailLoading(false);
    if (emailError) {
      setEmailMsg({ type: 'error', text: emailError });
      return;
    }
    setEmailMsg({ type: 'success', text: 'Un email de confirmation a été envoyé à votre nouvelle adresse. Le changement prendra effet après confirmation.' });
    setNewEmail('');
    setTimeout(() => {
      setShowEmailModal(false);
      setEmailMsg(null);
    }, 4000);
  }

  async function removeFavorite(favId: string, docId: string) {
    if (!user) return;
    setFavorites((prev) => prev.filter((f) => f.id !== favId));
    await supabase.from('favorites').delete().eq('user_id', user.id).eq('document_id', docId);
  }

  async function clearHistory() {
    if (!user) return;
    await supabase.from('consultation_history').delete().eq('user_id', user.id);
    setHistory([]);
  }

  const userRole: UserRole = profile?.role ?? 'utilisateur';
  const displayName = [profile?.first_name, profile?.last_name].filter(Boolean).join(' ') || profile?.username || 'Utilisateur';

  const tabs: { id: TabId; label: string; icon: typeof User }[] = [
    { id: 'informations', label: 'Informations', icon: User },
    { id: 'favoris', label: 'Favoris', icon: Heart },
    { id: 'historique', label: 'Historique', icon: History },
    { id: 'contributions', label: 'Contributions', icon: FileText },
    { id: 'securite', label: 'Sécurité', icon: Shield },
  ];

  const categoryColor = (cat: string | null): string => {
    const map: Record<string, string> = {
      'Histoire': 'bg-amber-100 text-amber-800',
      'Sciences': 'bg-blue-100 text-blue-800',
      'Littérature': 'bg-emerald-100 text-emerald-800',
      'Droit': 'bg-rose-100 text-rose-800',
      'Philosophie': 'bg-violet-100 text-violet-800',
      'Art': 'bg-teal-100 text-teal-800',
    };
    return map[cat ?? ''] ?? 'bg-stone-100 text-stone-700';
  };

  return (
    <div className="min-h-screen pt-24 pb-20 animate-fade-in">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="pt-8 pb-10">
          <h1 className="font-serif text-3xl lg:text-4xl font-semibold text-stone-900">Profil</h1>
        </div>

        {savedMsg && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-3 animate-fade-up">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
            <p className="text-sm text-emerald-800">Profil mis à jour avec succès.</p>
          </div>
        )}
        {error && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-3 animate-fade-up">
            <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
            <p className="text-sm text-rose-800">{error}</p>
          </div>
        )}

        {/* Profile header card */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6 lg:p-8 mb-6">
          <div className="flex items-center gap-6 flex-wrap">
            {/* Avatar */}
            <div className="relative group">
              <div className="w-20 h-20 rounded-full bg-stone-900 text-white flex items-center justify-center text-2xl font-semibold overflow-hidden">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  profile?.username?.charAt(0).toUpperCase() ?? <User className="w-10 h-10" />
                )}
              </div>
              {editing && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={avatarUploading}
                  className="absolute inset-0 rounded-full bg-stone-900/60 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-100"
                >
                  {avatarUploading ? (
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <Camera className="w-6 h-6" />
                  )}
                </button>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarUpload}
                className="hidden"
              />
            </div>

            {/* Name and email */}
            <div className="flex-1 min-w-0">
              <h2 className="font-serif text-xl font-semibold text-stone-900">{displayName}</h2>
              <p className="text-sm text-stone-500 mt-0.5">{user.email}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className={`px-3 py-0.5 rounded-full text-xs font-medium ${ROLE_BADGE_COLORS[userRole]}`}>
                  {ROLE_LABELS[userRole]}
                </span>
                <span className="px-3 py-0.5 rounded-full text-xs font-medium bg-stone-100 text-stone-600">
                  {LANGUAGES.find((l) => l.code === preferredLanguage)?.label ?? 'Français'}
                </span>
              </div>
            </div>

            <button
              onClick={() => setEditing(!editing)}
              className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                editing
                  ? 'text-stone-500 hover:bg-stone-100'
                  : 'text-stone-700 hover:bg-stone-100'
              }`}
            >
              {editing ? (
                <>Annuler</>
              ) : (
                <>
                  <Edit2 className="w-4 h-4" />
                  Modifier
                </>
              )}
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mb-6 overflow-x-auto pb-1">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-xl whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-stone-900 text-white'
                  : 'bg-white text-stone-600 hover:bg-stone-100 border border-stone-200'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        {/* Informations */}
        {activeTab === 'informations' && (
          <div className="bg-white rounded-2xl border border-stone-200 p-6 lg:p-8 animate-fade-in">
            {editing ? (
              <div className="space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-2">Prénom</label>
                    <input
                      type="text"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      placeholder="Jean"
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-2">Nom</label>
                    <input
                      type="text"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      placeholder="Dupont"
                      className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Nom d'utilisateur</label>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2 flex items-center gap-2">
                    <Globe className="w-4 h-4 text-stone-500" />
                    Langue préférée
                  </label>
                  <select
                    value={preferredLanguage}
                    onChange={(e) => setPreferredLanguage(e.target.value)}
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                  >
                    {LANGUAGES.map((lang) => (
                      <option key={lang.code} value={lang.code}>{lang.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Biographie</label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    rows={3}
                    placeholder="Quelques mots sur vous..."
                    className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all resize-none"
                  />
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex-1 px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl">
                    <p className="text-xs text-stone-500 mb-1">E-mail (changement via sécurité)</p>
                    <p className="text-sm text-stone-800">{user.email}</p>
                  </div>
                  <button
                    onClick={() => { setShowEmailModal(true); setEditing(false); }}
                    className="px-4 py-3 text-sm font-medium text-stone-700 rounded-xl border border-stone-300 hover:bg-stone-100 transition-colors whitespace-nowrap"
                  >
                    Changer
                  </button>
                </div>
                <div className="flex justify-end">
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-colors disabled:opacity-50"
                  >
                    <Save className="w-4 h-4" />
                    {saving ? 'Enregistrement...' : 'Enregistrer'}
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-5">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <p className="text-xs font-medium text-stone-500 uppercase tracking-wider mb-1">Prénom</p>
                    <p className="text-stone-800">{profile?.first_name || '—'}</p>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-stone-500 uppercase tracking-wider mb-1">Nom</p>
                    <p className="text-stone-800">{profile?.last_name || '—'}</p>
                  </div>
                </div>
                <div>
                  <p className="text-xs font-medium text-stone-500 uppercase tracking-wider mb-1">Nom d'utilisateur</p>
                  <p className="text-stone-800">{profile?.username || '—'}</p>
                </div>
                <div>
                  <p className="text-xs font-medium text-stone-500 uppercase tracking-wider mb-1">E-mail</p>
                  <p className="text-stone-800">{user.email}</p>
                </div>
                <div>
                  <p className="text-xs font-medium text-stone-500 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5" />
                    Langue préférée
                  </p>
                  <p className="text-stone-800">{LANGUAGES.find((l) => l.code === preferredLanguage)?.label ?? 'Français'}</p>
                </div>
                <div>
                  <p className="text-xs font-medium text-stone-500 uppercase tracking-wider mb-1">Niveau d'accès</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${ROLE_BADGE_COLORS[userRole]}`}>
                    {ROLE_LABELS[userRole]}
                  </span>
                </div>
                {profile?.bio && (
                  <div>
                    <p className="text-xs font-medium text-stone-500 uppercase tracking-wider mb-1">Biographie</p>
                    <p className="text-stone-800">{profile.bio}</p>
                  </div>
                )}
                {!profile?.bio && !profile?.first_name && !profile?.last_name && (
                  <p className="text-sm text-stone-400 italic">Aucune information supplémentaire. Cliquez sur « Modifier » pour compléter votre profil.</p>
                )}
              </div>
            )}
          </div>
        )}

        {/* Favoris */}
        {activeTab === 'favoris' && (
          <div className="bg-white rounded-2xl border border-stone-200 p-6 lg:p-8 animate-fade-in">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-serif text-xl font-semibold text-stone-900 flex items-center gap-2">
                <Heart className="w-5 h-5 text-rose-500" />
                Mes favoris
              </h3>
              <button
                onClick={() => onNavigate('bibliotheque')}
                className="text-sm font-medium text-stone-600 hover:text-stone-900 transition-colors"
              >
                Parcourir la bibliothèque
              </button>
            </div>

            {favorites.length === 0 ? (
              <div className="text-center py-10">
                <div className="w-14 h-14 rounded-2xl bg-stone-100 flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-7 h-7 text-stone-400" />
                </div>
                <p className="text-stone-600">Vous n'avez pas encore de favoris.</p>
                <button
                  onClick={() => onNavigate('bibliotheque')}
                  className="mt-4 text-sm font-semibold text-stone-900 hover:underline"
                >
                  Explorer la bibliothèque
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {favorites.map((fav) => (
                  <div key={fav.id} className="flex items-center justify-between p-4 rounded-xl bg-stone-50 hover:bg-stone-100 transition-colors">
                    <div className="min-w-0">
                      <p className="font-medium text-stone-900 truncate">{fav.documents[0]?.title ?? 'Document supprimé'}</p>
                      <div className="flex items-center gap-3 mt-1">
                        {fav.documents[0]?.category && (
                          <span className={`text-xs px-2 py-0.5 rounded-full ${categoryColor(fav.documents[0].category)}`}>
                            {fav.documents[0].category}
                          </span>
                        )}
                        {fav.documents[0]?.author && <span className="text-xs text-stone-500">{fav.documents[0].author}</span>}
                      </div>
                    </div>
                    <button
                      onClick={() => removeFavorite(fav.id, fav.document_id)}
                      className="p-2 rounded-lg text-stone-400 hover:text-rose-500 hover:bg-rose-50 transition-colors flex-shrink-0"
                      aria-label="Retirer des favoris"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Historique */}
        {activeTab === 'historique' && (
          <div className="bg-white rounded-2xl border border-stone-200 p-6 lg:p-8 animate-fade-in">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-serif text-xl font-semibold text-stone-900 flex items-center gap-2">
                <History className="w-5 h-5 text-stone-600" />
                Historique de consultation
              </h3>
              {history.length > 0 && (
                <button
                  onClick={clearHistory}
                  className="flex items-center gap-1.5 text-sm font-medium text-stone-500 hover:text-rose-500 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  Effacer
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <div className="text-center py-10">
                <div className="w-14 h-14 rounded-2xl bg-stone-100 flex items-center justify-center mx-auto mb-4">
                  <History className="w-7 h-7 text-stone-400" />
                </div>
                <p className="text-stone-600">Aucune consultation pour le moment.</p>
                <button
                  onClick={() => onNavigate('bibliotheque')}
                  className="mt-4 text-sm font-semibold text-stone-900 hover:underline"
                >
                  Explorer la bibliothèque
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {history.map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between p-3.5 rounded-xl bg-stone-50 hover:bg-stone-100 transition-colors">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-lg bg-stone-200 text-stone-600 flex items-center justify-center flex-shrink-0">
                        <FileText className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-stone-900 truncate">{entry.documents[0]?.title ?? 'Document supprimé'}</p>
                        {entry.documents[0]?.category && (
                          <span className={`inline-block mt-0.5 text-xs px-2 py-0.5 rounded-full ${categoryColor(entry.documents[0].category)}`}>
                            {entry.documents[0].category}
                          </span>
                        )}
                      </div>
                    </div>
                    <span className="text-xs text-stone-400 flex-shrink-0">
                      {new Date(entry.consulted_at).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Contributions */}
        {activeTab === 'contributions' && (
          <div className="bg-white rounded-2xl border border-stone-200 p-6 lg:p-8 animate-fade-in">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-serif text-xl font-semibold text-stone-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-stone-600" />
                Mes contributions
              </h3>
              <button
                onClick={() => onNavigate('contribution')}
                className="text-sm font-medium text-stone-600 hover:text-stone-900 transition-colors"
              >
                + Ajouter
              </button>
            </div>

            {docs.length === 0 ? (
              <div className="text-center py-10">
                <div className="w-14 h-14 rounded-2xl bg-stone-100 flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="w-7 h-7 text-stone-400" />
                </div>
                <p className="text-stone-600">Vous n'avez pas encore contribué de document.</p>
                <button
                  onClick={() => onNavigate('contribution')}
                  className="mt-4 text-sm font-semibold text-stone-900 hover:underline"
                >
                  Contribuer maintenant
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {docs.map((doc) => (
                  <div key={doc.id} className="flex items-center justify-between p-4 rounded-xl bg-stone-50 hover:bg-stone-100 transition-colors">
                    <div>
                      <p className="font-medium text-stone-900">{doc.title}</p>
                      <div className="flex items-center gap-3 mt-1">
                        {doc.category && <span className={`text-xs px-2 py-0.5 rounded-full ${categoryColor(doc.category)}`}>{doc.category}</span>}
                        <span className={`text-xs px-2 py-0.5 rounded-full ${doc.is_free ? 'bg-emerald-100 text-emerald-700' : 'bg-stone-200 text-stone-600'}`}>
                          {doc.is_free ? 'Gratuit' : 'Premium'}
                        </span>
                      </div>
                    </div>
                    <span className="text-xs text-stone-400">{new Date(doc.created_at).toLocaleDateString('fr-FR')}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Sécurité */}
        {activeTab === 'securite' && (
          <div className="bg-white rounded-2xl border border-stone-200 p-6 lg:p-8 animate-fade-in">
            <div className="flex items-center gap-3 mb-6">
              <Shield className="w-5 h-5 text-stone-700" />
              <h3 className="font-serif text-xl font-semibold text-stone-900">Sécurité</h3>
            </div>

            <div className="space-y-4">
              {/* Email */}
              <div className="flex items-center justify-between p-4 rounded-xl bg-stone-50 hover:bg-stone-100 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white border border-stone-200 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-stone-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-stone-900">Changer l'adresse e-mail</p>
                    <p className="text-xs text-stone-500">{user.email}</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowEmailModal(true)}
                  className="px-4 py-2 text-sm font-medium text-stone-700 rounded-lg border border-stone-300 hover:bg-white transition-colors"
                >
                  Modifier
                </button>
              </div>

              {/* Password */}
              <div className="flex items-center justify-between p-4 rounded-xl bg-stone-50 hover:bg-stone-100 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white border border-stone-200 flex items-center justify-center">
                    <KeyRound className="w-5 h-5 text-stone-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-stone-900">Changer le mot de passe</p>
                    <p className="text-xs text-stone-500">Mettez à jour votre mot de passe</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowPasswordModal(true)}
                  className="px-4 py-2 text-sm font-medium text-stone-700 rounded-lg border border-stone-300 hover:bg-white transition-colors"
                >
                  Modifier
                </button>
              </div>

              {/* Sign out all */}
              <div className="flex items-center justify-between p-4 rounded-xl bg-stone-50 hover:bg-stone-100 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white border border-stone-200 flex items-center justify-center">
                    <Monitor className="w-5 h-5 text-stone-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-stone-900">Déconnecter toutes les sessions</p>
                    <p className="text-xs text-stone-500">Fermez votre session sur tous les appareils</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowSignOutAllModal(true)}
                  className="px-4 py-2 text-sm font-medium text-stone-700 rounded-lg border border-stone-300 hover:bg-white transition-colors"
                >
                  Déconnecter
                </button>
              </div>
            </div>

            {/* Sign out */}
            <div className="mt-6 pt-6 border-t border-stone-200 flex justify-end">
              <button
                onClick={handleSignOut}
                className="flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-stone-600 rounded-xl hover:bg-stone-100 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                Se déconnecter
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Change password modal */}
      {showPasswordModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 animate-fade-in"
          onClick={() => { setShowPasswordModal(false); setPasswordMsg(null); }}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 lg:p-8 animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-stone-100 flex items-center justify-center">
                  <Lock className="w-5 h-5 text-stone-700" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-stone-900">Changer le mot de passe</h3>
              </div>
              <button
                onClick={() => { setShowPasswordModal(false); setPasswordMsg(null); }}
                className="p-1.5 rounded-lg text-stone-400 hover:bg-stone-100 hover:text-stone-700 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {passwordMsg && (
              <div className={`mb-4 p-3.5 rounded-xl flex items-center gap-3 ${
                passwordMsg.type === 'success' ? 'bg-emerald-50 border border-emerald-200' : 'bg-rose-50 border border-rose-200'
              }`}>
                {passwordMsg.type === 'success'
                  ? <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                  : <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />}
                <p className={`text-sm ${passwordMsg.type === 'success' ? 'text-emerald-800' : 'text-rose-800'}`}>{passwordMsg.text}</p>
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-2">Nouveau mot de passe</label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  minLength={6}
                  className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-2">Confirmer le nouveau mot de passe</label>
                <input
                  type="password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  placeholder="••••••••"
                  minLength={6}
                  className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                />
              </div>
              <button
                onClick={handleChangePassword}
                disabled={passwordLoading}
                className="w-full py-3.5 text-sm font-semibold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {passwordLoading ? 'Modification...' : 'Confirmer le changement'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Change email modal */}
      {showEmailModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 animate-fade-in"
          onClick={() => { setShowEmailModal(false); setEmailMsg(null); }}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 lg:p-8 animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-stone-100 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-stone-700" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-stone-900">Changer l'e-mail</h3>
              </div>
              <button
                onClick={() => { setShowEmailModal(false); setEmailMsg(null); }}
                className="p-1.5 rounded-lg text-stone-400 hover:bg-stone-100 hover:text-stone-700 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {emailMsg && (
              <div className={`mb-4 p-3.5 rounded-xl flex items-start gap-3 ${
                emailMsg.type === 'success' ? 'bg-emerald-50 border border-emerald-200' : 'bg-rose-50 border border-rose-200'
              }`}>
                {emailMsg.type === 'success'
                  ? <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                  : <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0 mt-0.5" />}
                <p className={`text-sm ${emailMsg.type === 'success' ? 'text-emerald-800' : 'text-rose-800'}`}>{emailMsg.text}</p>
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-stone-700 mb-2">Nouvelle adresse e-mail</label>
                <input
                  type="email"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  placeholder="nouvel@email.com"
                  className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                />
                <p className="mt-2 text-xs text-stone-500">Un email de confirmation sera envoyé à la nouvelle adresse.</p>
              </div>
              <button
                onClick={handleChangeEmail}
                disabled={emailLoading}
                className="w-full py-3.5 text-sm font-semibold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {emailLoading ? 'Envoi...' : 'Confirmer le changement'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sign out all sessions modal */}
      {showSignOutAllModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 animate-fade-in"
          onClick={() => setShowSignOutAllModal(false)}
        >
          <div
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 lg:p-8 animate-scale-in"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-stone-100 flex items-center justify-center">
                  <Monitor className="w-5 h-5 text-stone-700" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-stone-900">Déconnecter toutes les sessions</h3>
              </div>
              <button
                onClick={() => setShowSignOutAllModal(false)}
                className="p-1.5 rounded-lg text-stone-400 hover:bg-stone-100 hover:text-stone-700 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-sm text-stone-600 mb-6">
              Cette action va fermer votre session sur tous les appareils connectés à votre compte Archivo,
              y compris celui-ci. Vous devrez vous reconnecter partout.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowSignOutAllModal(false)}
                className="flex-1 py-3 text-sm font-medium text-stone-700 rounded-xl border border-stone-300 hover:bg-stone-50 transition-colors"
              >
                Annuler
              </button>
              <button
                onClick={handleSignOutAll}
                disabled={signOutAllLoading}
                className="flex-1 py-3 text-sm font-semibold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {signOutAllLoading ? 'Déconnexion...' : 'Tout déconnecter'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
