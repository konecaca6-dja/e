import { useState } from 'react';
import { Mail, Lock, AlertCircle, BookOpen, ArrowRight, User, CheckCircle2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { type Page } from '@/types/navigation';

interface AuthPageProps {
  mode: 'signin' | 'signup' | 'forgot';
  onNavigate: (page: Page) => void;
}

export default function AuthPage({ mode, onNavigate }: AuthPageProps) {
  const { signIn, signUp, resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [username, setUsername] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const isSignUp = mode === 'signup';
  const isForgot = mode === 'forgot';
  const isSignIn = mode === 'signin';

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    if (isSignUp) {
      if (!username.trim()) {
        setError('Le nom d\'utilisateur est obligatoire.');
        setLoading(false);
        return;
      }
      if (password !== confirmPassword) {
        setError('Les mots de passe ne correspondent pas.');
        setLoading(false);
        return;
      }
      if (password.length < 6) {
        setError('Le mot de passe doit contenir au moins 6 caractères.');
        setLoading(false);
        return;
      }
      const { error: signUpError } = await signUp({
        email,
        password,
        username: username.trim(),
        firstName: firstName.trim(),
        lastName: lastName.trim(),
      });
      if (signUpError) {
        setError(signUpError);
        setLoading(false);
        return;
      }
      setSuccess('Compte créé avec succès ! Un email de confirmation vous a été envoyé. Vérifiez votre boîte de réception avant de vous connecter.');
      setLoading(false);
    } else if (isSignIn) {
      const { error: signInError } = await signIn(email, password);
      if (signInError) {
        setError(signInError);
        setLoading(false);
        return;
      }
      onNavigate('profil');
    } else if (isForgot) {
      const { error: resetError } = await resetPassword(email);
      if (resetError) {
        setError(resetError);
        setLoading(false);
        return;
      }
      setSuccess('Si cette adresse e-mail est associée à un compte, un lien de réinitialisation vous a été envoyé.');
      setLoading(false);
    }
  }

  const pageTitle = isSignUp ? 'Créer un compte' : isForgot ? 'Mot de passe oublié' : 'Se connecter';
  const pageSubtitle = isSignUp
    ? 'Rejoignez la communauté Archivo en quelques secondes.'
    : isForgot
    ? 'Saisissez votre email pour recevoir un lien de réinitialisation.'
    : 'Bon retour dans votre bibliothèque collaborative.';

  return (
    <div className="min-h-screen pt-24 pb-20 flex items-center justify-center animate-fade-in">
      <div className="max-w-md w-full px-4 sm:px-6">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-lg bg-stone-900 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-white" strokeWidth={2.5} />
            </div>
            <span className="font-serif text-2xl font-semibold text-stone-900">Archivo</span>
          </div>
          <h1 className="font-serif text-2xl font-semibold text-stone-900">{pageTitle}</h1>
          <p className="mt-2 text-sm text-stone-600">{pageSubtitle}</p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-2xl border border-stone-200 p-6 lg:p-8 shadow-sm">
          {error && (
            <div className="mb-5 p-4 rounded-xl bg-rose-50 border border-rose-200 flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 flex-shrink-0" />
              <p className="text-sm text-rose-800">{error}</p>
            </div>
          )}

          {success && (
            <div className="mb-5 p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-emerald-800">{success}</p>
                {isSignUp && (
                  <button
                    onClick={() => onNavigate('connexion')}
                    className="mt-3 text-sm font-semibold text-emerald-700 hover:underline"
                  >
                    Aller à la page de connexion
                  </button>
                )}
              </div>
            </div>
          )}

          {!success && (
            <form onSubmit={handleSubmit} className="space-y-5">
              {isSignUp && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-stone-700 mb-2">Prénom</label>
                      <input
                        type="text"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        placeholder="Jean"
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-stone-700 mb-2">Nom</label>
                      <input
                        type="text"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        placeholder="Dupont"
                        className="w-full px-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-stone-700 mb-2">Nom d'utilisateur</label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="votre_pseudo"
                        className="w-full pl-11 pr-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                        required
                      />
                    </div>
                  </div>
                </>
              )}

              <div>
                <label className="block text-sm font-medium text-stone-700 mb-2">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="vous@exemple.com"
                    className="w-full pl-11 pr-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                    required
                  />
                </div>
              </div>

              {!isForgot && (
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Mot de passe</label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      minLength={6}
                      className="w-full pl-11 pr-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                      required
                    />
                  </div>
                </div>
              )}

              {isSignUp && (
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Confirmer le mot de passe</label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      minLength={6}
                      className="w-full pl-11 pr-4 py-3 bg-stone-50 border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
                      required
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 text-base font-semibold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading
                  ? 'Chargement...'
                  : isSignUp
                  ? 'Créer mon compte'
                  : isForgot
                  ? 'Envoyer le lien'
                  : 'Se connecter'}
                {!loading && <ArrowRight className="w-5 h-5" />}
              </button>
            </form>
          )}

          {/* Links */}
          <div className="mt-6 space-y-2 text-center text-sm text-stone-600">
            {isSignIn && (
              <button
                onClick={() => onNavigate('mot-de-passe-oublie')}
                className="block w-full font-medium text-stone-500 hover:text-stone-900 transition-colors"
              >
                Mot de passe oublié ?
              </button>
            )}
            {isSignUp ? (
              <p>
                Déjà un compte ?{' '}
                <button
                  onClick={() => onNavigate('connexion')}
                  className="font-semibold text-stone-900 hover:underline"
                >
                  Se connecter
                </button>
              </p>
            ) : isForgot ? (
              <p>
                <button
                  onClick={() => onNavigate('connexion')}
                  className="font-semibold text-stone-900 hover:underline"
                >
                  Retour à la connexion
                </button>
              </p>
            ) : (
              <p>
                Pas encore de compte ?{' '}
                <button
                  onClick={() => onNavigate('inscription')}
                  className="font-semibold text-stone-900 hover:underline"
                >
                  Créer un compte
                </button>
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
