import { useState, useEffect, useCallback } from 'react';
import { Search, BookOpen, Filter, FileText, Heart, Eye } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';

interface Document {
  id: string;
  title: string;
  author: string | null;
  description: string | null;
  category: string | null;
  is_free: boolean;
  created_at: string;
}

const CATEGORIES = ['Histoire', 'Sciences', 'Littérature', 'Droit', 'Philosophie', 'Art', 'Autre'];

export default function LibraryPage() {
  const { user } = useAuth();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [viewedDocs, setViewedDocs] = useState<Set<string>>(new Set());

  useEffect(() => {
    async function load() {
      setLoading(true);
      let query = supabase
        .from('documents')
        .select('id, title, author, description, category, is_free, created_at')
        .eq('status', 'published')
        .order('created_at', { ascending: false });

      if (activeCategory) {
        query = query.eq('category', activeCategory);
      }

      const { data, error } = await query;
      if (!error && data) {
        setDocuments(data as Document[]);
      }
      setLoading(false);
    }
    load();
  }, [activeCategory]);

  useEffect(() => {
    if (!user) return;
    supabase
      .from('favorites')
      .select('document_id')
      .eq('user_id', user.id)
      .then(({ data }) => {
        if (data) {
          setFavorites(new Set(data.map((f) => f.document_id)));
        }
      });
  }, [user]);

  const toggleFavorite = useCallback(async (docId: string) => {
    if (!user) return;
    if (favorites.has(docId)) {
      setFavorites((prev) => {
        const next = new Set(prev);
        next.delete(docId);
        return next;
      });
      await supabase.from('favorites').delete().eq('user_id', user.id).eq('document_id', docId);
    } else {
      setFavorites((prev) => new Set(prev).add(docId));
      await supabase.from('favorites').insert({ user_id: user.id, document_id: docId });
    }
  }, [user, favorites]);

  const trackConsultation = useCallback(async (docId: string) => {
    if (!user || viewedDocs.has(docId)) return;
    setViewedDocs((prev) => new Set(prev).add(docId));
    await supabase.from('consultation_history').insert({ user_id: user.id, document_id: docId });
  }, [user, viewedDocs]);

  const filtered = documents.filter((doc) => {
    if (!search) return true;
    const s = search.toLowerCase();
    return (
      doc.title.toLowerCase().includes(s) ||
      doc.author?.toLowerCase().includes(s) ||
      doc.description?.toLowerCase().includes(s)
    );
  });

  const categoryColor = (cat: string | null): string => {
    const map: Record<string, string> = {
      'Histoire': 'bg-amber-100 text-amber-800',
      'Sciences': 'bg-blue-100 text-blue-800',
      'Littérature': 'bg-emerald-100 text-emerald-800',
      'Droit': 'bg-rose-100 text-rose-800',
      'Philosophie': 'bg-violet-100 text-violet-800',
      'Art': 'bg-teal-100 text-teal-800',
    };
    return map[cat ?? ''] ?? 'bg-stone-100 text-stone-700';
  };

  if (!user) {
    return (
      <div className="min-h-screen pt-32 pb-20 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-16 h-16 rounded-2xl bg-stone-100 flex items-center justify-center mx-auto mb-6">
            <BookOpen className="w-8 h-8 text-stone-400" />
          </div>
          <h2 className="font-serif text-2xl font-semibold text-stone-900 mb-3">Connexion requise</h2>
          <p className="text-stone-600">
            Connectez-vous pour accéder à la bibliothèque et explorer l'ensemble des documents.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-20 animate-fade-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="pt-8 pb-10">
          <h1 className="font-serif text-3xl lg:text-4xl font-semibold text-stone-900">Bibliothèque</h1>
          <p className="mt-3 text-stone-600 text-lg">
            Explorez l'ensemble des documents disponibles dans Archivo.
          </p>
        </div>

        {/* Search */}
        <div className="relative mb-6">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-stone-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher un document, un auteur..."
            className="w-full pl-12 pr-4 py-3.5 bg-white border border-stone-300 rounded-xl text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-900 focus:border-transparent transition-all"
          />
        </div>

        {/* Categories */}
        <div className="flex items-center gap-2 mb-8 overflow-x-auto pb-2">
          <Filter className="w-4 h-4 text-stone-500 flex-shrink-0" />
          <button
            onClick={() => setActiveCategory(null)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              !activeCategory ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
          >
            Toutes
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                activeCategory === cat ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Results */}
        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl p-6 border border-stone-200 animate-pulse">
                <div className="h-4 bg-stone-200 rounded w-20 mb-4" />
                <div className="h-6 bg-stone-200 rounded mb-3" />
                <div className="h-4 bg-stone-200 rounded w-3/4 mb-2" />
                <div className="h-4 bg-stone-200 rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-stone-100 flex items-center justify-center mx-auto mb-6">
              <FileText className="w-8 h-8 text-stone-400" />
            </div>
            <h3 className="font-serif text-xl font-semibold text-stone-900 mb-2">Aucun document trouvé</h3>
            <p className="text-stone-600">Essayez une autre recherche ou catégorie.</p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((doc) => {
              const isFav = favorites.has(doc.id);
              const isViewed = viewedDocs.has(doc.id);
              return (
                <div
                  key={doc.id}
                  className="group bg-white rounded-2xl p-6 border border-stone-200 hover:border-stone-300 hover:shadow-lg transition-all duration-300"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-2">
                      {doc.category && (
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${categoryColor(doc.category)}`}>
                          {doc.category}
                        </span>
                      )}
                      {doc.is_free && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-700">
                          Gratuit
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => toggleFavorite(doc.id)}
                      className={`p-1.5 rounded-lg transition-all ${
                        isFav ? 'text-rose-500 hover:bg-rose-50' : 'text-stone-300 hover:text-stone-500 hover:bg-stone-100'
                      }`}
                      aria-label="Ajouter aux favoris"
                    >
                      <Heart className={`w-5 h-5 ${isFav ? 'fill-current' : ''}`} />
                    </button>
                  </div>
                  <h3
                    className="font-serif text-lg font-semibold text-stone-900 mb-2 group-hover:text-stone-700 transition-colors cursor-pointer"
                    onClick={() => trackConsultation(doc.id)}
                  >
                    {doc.title}
                  </h3>
                  {doc.author && (
                    <p className="text-sm text-stone-500 mb-3">{doc.author}</p>
                  )}
                  {doc.description && (
                    <p className="text-sm text-stone-600 leading-relaxed line-clamp-3">{doc.description}</p>
                  )}
                  <div className="mt-4 flex items-center justify-between">
                    <p className="text-xs text-stone-400">
                      Ajouté le {new Date(doc.created_at).toLocaleDateString('fr-FR')}
                    </p>
                    {isViewed && (
                      <span className="flex items-center gap-1 text-xs text-stone-400">
                        <Eye className="w-3.5 h-3.5" />
                        Consulté
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
