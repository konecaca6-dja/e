import { Globe, Download, BookOpen, FileText, ArrowRight } from 'lucide-react';
import { type Page } from '@/types/navigation';

interface ResourcesPageProps {
  onNavigate: (page: Page) => void;
}

const resources = [
  { title: 'Encyclopédie universelle', category: 'Référence', description: 'Accès libre à une encyclopédie couvrant tous les domaines du savoir.', icon: BookOpen },
  { title: 'Manuels académiques ouverts', category: 'Éducation', description: 'Des manuels universitaires en accès libre pour apprendre à votre rythme.', icon: FileText },
  { title: 'Archives historiques', category: 'Histoire', description: 'Documents d\'archives numérisés et librement consultables.', icon: Globe },
  { title: 'Publications scientifiques', category: 'Sciences', description: 'Articles de recherche en accès ouvert dans toutes les disciplines.', icon: FileText },
  { title: 'Classiques de la littérature', category: 'Littérature', description: 'Les grandes œuvres de la littérature mondiale, librement accessibles.', icon: BookOpen },
  { title: 'Ressources juridiques', category: 'Droit', description: 'Textes légaux, jurisprudence et documents juridiques en accès libre.', icon: Globe },
];

export default function ResourcesPage({ onNavigate }: ResourcesPageProps) {
  return (
    <div className="min-h-screen pt-24 pb-20 animate-fade-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="pt-8 pb-12 text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100 border border-emerald-200 mb-6">
            <Download className="w-4 h-4 text-emerald-700" />
            <span className="text-sm font-medium text-emerald-700">100% gratuit</span>
          </div>
          <h1 className="font-serif text-3xl lg:text-4xl font-semibold text-stone-900">
            Ressources gratuites
          </h1>
          <p className="mt-4 text-lg text-stone-600">
            Une sélection de documents et ressources en accès libre, pour tous les
            curieux du savoir. Aucun compte requis.
          </p>
        </div>

        {/* Resources grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((res, i) => (
            <div
              key={i}
              className="group bg-white rounded-2xl p-6 border border-stone-200 hover:border-stone-300 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-xl bg-stone-100 group-hover:bg-stone-900 group-hover:text-white text-stone-700 flex items-center justify-center mb-5 transition-all duration-300">
                <res.icon className="w-6 h-6" />
              </div>
              <span className="text-xs font-medium text-stone-500 uppercase tracking-wider">{res.category}</span>
              <h3 className="mt-2 font-serif text-lg font-semibold text-stone-900 mb-3">{res.title}</h3>
              <p className="text-sm text-stone-600 leading-relaxed">{res.description}</p>
              <button className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-stone-900 hover:gap-2.5 transition-all">
                Consulter
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-20 bg-stone-900 rounded-2xl p-8 lg:p-12 text-center">
          <h2 className="font-serif text-2xl lg:text-3xl font-semibold text-white">
            Envie d'aller plus loin ?
          </h2>
          <p className="mt-3 text-stone-400 max-w-xl mx-auto">
            Créez un compte pour accéder à la bibliothèque complète, contribuer et
            personnaliser votre expérience.
          </p>
          <button
            onClick={() => onNavigate('inscription')}
            className="mt-8 px-8 py-3.5 text-base font-semibold text-stone-900 bg-white rounded-xl hover:bg-stone-100 transition-all duration-200 shadow-lg"
          >
            Créer un compte gratuit
          </button>
        </div>
      </div>
    </div>
  );
}
