import { Lock, Check, Sparkles, Users, BookOpen } from 'lucide-react';
import { type Page } from '@/types/navigation';

interface AccessPageProps {
  onNavigate: (page: Page) => void;
}

const plans = [
  {
    name: 'Gratuit',
    price: '0 €',
    period: '/mois',
    description: 'Pour découvrir Archivo et accéder aux ressources libres.',
    features: [
      'Accès aux ressources gratuites',
      'Recherche dans le catalogue public',
      'Jusqu\'à 5 contributions par mois',
      'Création de favoris',
    ],
    cta: 'Commencer gratuitement',
    highlight: false,
    page: 'inscription' as Page,
  },
  {
    name: 'Premium',
    price: '9,90 €',
    period: '/mois',
    description: 'Accès complet à la bibliothèque et outils avancés.',
    features: [
      'Tout le plan Gratuit',
      'Accès à tous les documents premiums',
      'Recherche sémantique avancée',
      'Contributions illimitées',
      'Annotations et notes personnelles',
      'Export en PDF et EPUB',
    ],
    cta: 'Choisir Premium',
    highlight: true,
    page: 'inscription' as Page,
  },
  {
    name: 'Institutionnel',
    price: 'Sur devis',
    period: '',
    description: 'Pour les bibliothèques, universités et organisations.',
    features: [
      'Tout le plan Premium',
      'Jusqu\'à 100 utilisateurs',
      'Espace collaboratif dédié',
      'Statistiques et analytics',
      'Support prioritaire',
      'Personnalisation de la plateforme',
    ],
    cta: 'Nous contacter',
    highlight: false,
    page: 'accueil' as Page,
  },
];

export default function AccessPage({ onNavigate }: AccessPageProps) {
  return (
    <div className="min-h-screen pt-24 pb-20 animate-fade-in">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="pt-8 pb-12 text-center max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-stone-900/5 border border-stone-300 mb-6">
            <Lock className="w-4 h-4 text-stone-600" />
            <span className="text-sm font-medium text-stone-600">Modalités d'accès</span>
          </div>
          <h1 className="font-serif text-3xl lg:text-4xl font-semibold text-stone-900">
            Choisissez votre formule d'accès
          </h1>
          <p className="mt-4 text-lg text-stone-600">
            Archivo propose différentes formules pour s'adapter à vos besoins,
            du simple lecteur à l'institution complète.
          </p>
        </div>

        {/* Plans */}
        <div className="grid lg:grid-cols-3 gap-6 lg:gap-8">
          {plans.map((plan, i) => (
            <div
              key={i}
              className={`relative bg-white rounded-2xl p-8 border transition-all duration-300 hover:-translate-y-1 ${
                plan.highlight
                  ? 'border-stone-900 shadow-xl lg:scale-105'
                  : 'border-stone-200 hover:shadow-lg'
              }`}
            >
              {plan.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-stone-900 text-white text-xs font-semibold flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3" />
                  Le plus choisi
                </div>
              )}

              <h3 className="font-serif text-2xl font-semibold text-stone-900">{plan.name}</h3>
              <div className="mt-4 flex items-baseline gap-1">
                <span className="text-4xl font-bold text-stone-900">{plan.price}</span>
                <span className="text-stone-500">{plan.period}</span>
              </div>
              <p className="mt-3 text-sm text-stone-600 leading-relaxed">{plan.description}</p>

              <ul className="mt-6 space-y-3">
                {plan.features.map((feat, j) => (
                  <li key={j} className="flex items-start gap-3">
                    <Check className="w-5 h-5 text-stone-700 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-stone-700">{feat}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => onNavigate(plan.page)}
                className={`mt-8 w-full py-3.5 text-sm font-semibold rounded-xl transition-all duration-200 ${
                  plan.highlight
                    ? 'bg-stone-900 text-white hover:bg-stone-800 shadow-lg'
                    : 'bg-stone-100 text-stone-900 hover:bg-stone-200'
                }`}
              >
                {plan.cta}
              </button>
            </div>
          ))}
        </div>

        {/* Info section */}
        <div className="mt-20 grid sm:grid-cols-3 gap-6">
          {[
            { icon: BookOpen, title: 'Accès aux collections', desc: 'Des milliers de documents dans tous les domaines du savoir.' },
            { icon: Users, title: 'Communauté active', desc: 'Échangez avec des passionnés et des experts de tous horizons.' },
            { icon: Sparkles, title: 'Outils intelligents', desc: 'Recherche sémantique, catégorisation automatique et plus encore.' },
          ].map((item, i) => (
            <div key={i} className="text-center p-6">
              <div className="w-12 h-12 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center mx-auto mb-4">
                <item.icon className="w-6 h-6" />
              </div>
              <h4 className="font-serif text-lg font-semibold text-stone-900 mb-2">{item.title}</h4>
              <p className="text-sm text-stone-600">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
