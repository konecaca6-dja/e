import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { type UserRole } from '@/types/navigation';

interface Profile {
  id: string;
  username: string;
  full_name: string | null;
  first_name: string | null;
  last_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  preferred_language: string;
  role: UserRole;
}

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  signUp: (params: {
    email: string;
    password: string;
    username: string;
    firstName: string;
    lastName: string;
  }) => Promise<{ error: string | null }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  signOutAllSessions: () => Promise<{ error: string | null }>;
  resetPassword: (email: string) => Promise<{ error: string | null }>;
  changePassword: (newPassword: string) => Promise<{ error: string | null }>;
  updateEmail: (newEmail: string) => Promise<{ error: string | null }>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

function mapAuthError(message: string): string {
  if (message.includes('Invalid login credentials')) return 'Email ou mot de passe incorrect.';
  if (message.includes('User already registered') || message.includes('already been registered'))
    return 'Un compte existe déjà avec cet email.';
  if (message.includes('Password should be at least'))
    return 'Le mot de passe doit contenir au moins 6 caractères.';
  if (message.includes('Unable to validate email address'))
    return 'Adresse e-mail invalide.';
  if (message.includes('Email not confirmed'))
    return 'Email non confirmé. Vérifiez votre boîte de réception.';
  return 'Une erreur est survenue. Veuillez réessayer.';
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  async function loadProfile(userId: string) {
    const { data } = await supabase
      .from('profiles')
      .select('id, username, full_name, first_name, last_name, bio, avatar_url, preferred_language, role')
      .eq('id', userId)
      .maybeSingle();
    setProfile(data as Profile | null);
  }

  async function refreshProfile() {
    if (user) {
      await loadProfile(user.id);
    }
  }

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        loadProfile(session.user.id).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession);
      setUser(newSession?.user ?? null);
      if (newSession?.user) {
        (async () => {
          await loadProfile(newSession.user.id);
        })();
      } else {
        setProfile(null);
      }
    });
  }, []);

  async function signUp({ email, password, username, firstName, lastName }: {
    email: string;
    password: string;
    username: string;
    firstName: string;
    lastName: string;
  }) {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username,
            first_name: firstName || undefined,
            last_name: lastName || undefined,
          },
        },
      });
      if (error) return { error: mapAuthError(error.message) };
      if (data.user) {
        const { error: profileError } = await supabase.from('profiles').insert({
          id: data.user.id,
          username,
          first_name: firstName || null,
          last_name: lastName || null,
          full_name: [firstName, lastName].filter(Boolean).join(' ') || null,
          role: 'utilisateur',
        });
        if (profileError) {
          console.error('Profile creation failed', profileError);
          return { error: 'Compte créé mais erreur lors de la création du profil. Contactez le support.' };
        }
      }
      return { error: null };
    } catch {
      return { error: 'Une erreur est survenue. Veuillez réessayer.' };
    }
  }

  async function signIn(email: string, password: string) {
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) return { error: mapAuthError(error.message) };
      return { error: null };
    } catch {
      return { error: 'Une erreur est survenue. Veuillez réessayer.' };
    }
  }

  async function signOut() {
    await supabase.auth.signOut();
    setProfile(null);
  }

  async function signOutAllSessions() {
    try {
      const { error } = await supabase.auth.signOut({ scope: 'global' });
      if (error) return { error: mapAuthError(error.message) };
      setProfile(null);
      return { error: null };
    } catch {
      return { error: 'Une erreur est survenue lors de la déconnexion.' };
    }
  }

  async function resetPassword(email: string) {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/`,
      });
      if (error) return { error: mapAuthError(error.message) };
      return { error: null };
    } catch {
      return { error: 'Une erreur est survenue. Veuillez réessayer.' };
    }
  }

  async function changePassword(newPassword: string) {
    try {
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) return { error: mapAuthError(error.message) };
      return { error: null };
    } catch {
      return { error: 'Une erreur est survenue lors du changement de mot de passe.' };
    }
  }

  async function updateEmail(newEmail: string) {
    try {
      const { error } = await supabase.auth.updateUser({ email: newEmail });
      if (error) return { error: mapAuthError(error.message) };
      return { error: null };
    } catch {
      return { error: 'Une erreur est survenue lors du changement d\'email.' };
    }
  }

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        profile,
        loading,
        signUp,
        signIn,
        signOut,
        signOutAllSessions,
        resetPassword,
        changePassword,
        updateEmail,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
