import { useState } from 'react';
import { Menu, X, BookOpen, User } from 'lucide-react';
import { NAV_ITEMS, type Page, ROLE_LABELS, ROLE_BADGE_COLORS, type UserRole } from '@/types/navigation';
import { useAuth } from '@/context/AuthContext';

interface NavbarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

export default function Navbar({ currentPage, onNavigate }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, profile } = useAuth();

  const handleNav = (page: Page) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  const userRole: UserRole = profile?.role ?? 'utilisateur';

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 glass border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <button
            onClick={() => handleNav('accueil')}
            className="flex items-center gap-2 text-stone-900 hover:opacity-80 transition-opacity"
          >
            <div className="w-9 h-9 rounded-lg bg-stone-900 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-white" strokeWidth={2.5} />
            </div>
            <span className="font-serif text-xl font-semibold tracking-tight">Archivo</span>
          </button>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`px-4 py-2 text-sm font-medium rounded-lg transition-all duration-200 ${
                  currentPage === item.id
                    ? 'bg-stone-900 text-white'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Desktop auth */}
          <div className="hidden lg:flex items-center gap-3">
            {user ? (
              <button
                onClick={() => handleNav('profil')}
                className="flex items-center gap-2.5 px-4 py-2 text-sm font-medium text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
              >
                <div className="w-7 h-7 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs font-semibold">
                  {profile?.username?.charAt(0).toUpperCase() ?? <User className="w-4 h-4" />}
                </div>
                <span>{profile?.username ?? 'Profil'}</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${ROLE_BADGE_COLORS[userRole]}`}>
                  {ROLE_LABELS[userRole]}
                </span>
              </button>
            ) : (
              <>
                <button
                  onClick={() => handleNav('connexion')}
                  className="px-4 py-2 text-sm font-medium text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
                >
                  Se connecter
                </button>
                <button
                  onClick={() => handleNav('inscription')}
                  className="px-5 py-2 text-sm font-semibold text-white bg-stone-900 rounded-lg hover:bg-stone-800 transition-colors shadow-sm"
                >
                  Créer un compte
                </button>
              </>
            )}
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden p-2 rounded-lg text-stone-700 hover:bg-stone-100 transition-colors"
            aria-label="Menu"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden py-4 border-t border-stone-200 animate-fade-in">
            <div className="flex flex-col gap-1">
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`px-4 py-3 text-left text-sm font-medium rounded-lg transition-colors ${
                    currentPage === item.id
                      ? 'bg-stone-900 text-white'
                      : 'text-stone-600 hover:bg-stone-100'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <div className="border-t border-stone-200 mt-2 pt-2">
                {user ? (
                  <button
                    onClick={() => handleNav('profil')}
                    className="px-4 py-3 text-left text-sm font-medium text-stone-700 rounded-lg hover:bg-stone-100 transition-colors w-full flex items-center gap-2"
                  >
                    {profile?.username ?? 'Profil'}
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${ROLE_BADGE_COLORS[userRole]}`}>
                      {ROLE_LABELS[userRole]}
                    </span>
                  </button>
                ) : (
                  <>
                    <button
                      onClick={() => handleNav('connexion')}
                      className="px-4 py-3 text-left text-sm font-medium text-stone-700 rounded-lg hover:bg-stone-100 transition-colors w-full"
                    >
                      Se connecter
                    </button>
                    <button
                      onClick={() => handleNav('inscription')}
                      className="px-4 py-3 text-left text-sm font-semibold text-white bg-stone-900 rounded-lg mt-1"
                    >
                      Créer un compte
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
