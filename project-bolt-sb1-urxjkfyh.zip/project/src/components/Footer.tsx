import { BookOpen, Mail } from 'lucide-react';
import { type Page } from '@/types/navigation';

interface FooterProps {
  onNavigate: (page: Page) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-stone-900 text-stone-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-lg bg-white/10 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-white" strokeWidth={2.5} />
              </div>
              <span className="font-serif text-xl font-semibold text-white">Archivo</span>
            </div>
            <p className="text-sm leading-relaxed max-w-md text-stone-400">
              Bibliothèque numérique intelligente et collaborative. Archivo rassemble,
              organise et partage le savoir documentaire pour tous les curieux, chercheurs
              et passionnés de connaissance.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Navigation</h4>
            <ul className="space-y-2 text-sm">
              <li><button onClick={() => onNavigate('bibliotheque')} className="hover:text-white transition-colors">Bibliothèque</button></li>
              <li><button onClick={() => onNavigate('contribution')} className="hover:text-white transition-colors">Contribution</button></li>
              <li><button onClick={() => onNavigate('acces')} className="hover:text-white transition-colors">Accès</button></li>
              <li><button onClick={() => onNavigate('ressources')} className="hover:text-white transition-colors">Ressources gratuites</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-white mb-4">Contact</h4>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <span>contact@archivo.fr</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-6 text-xs text-stone-500 text-center">
          © {new Date().getFullYear()} Archivo. Tous droits réservés.
        </div>
      </div>
    </footer>
  );
}
