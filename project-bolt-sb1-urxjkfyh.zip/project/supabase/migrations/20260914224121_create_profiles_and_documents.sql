/*
# Archivo — Base schema: profiles and documents

1. New Tables
- `profiles`
  - `id` (uuid, primary key, references auth.users)
  - `username` (text, unique, not null) — display name
  - `full_name` (text) — optional real name
  - `bio` (text) — optional short biography
  - `avatar_url` (text) — optional avatar image URL
  - `created_at` (timestamptz, default now())
- `documents`
  - `id` (uuid, primary key)
  - `title` (text, not null) — document title
  - `author` (text) — document author/creator
  - `description` (text) — summary or abstract
  - `category` (text) — e.g. "Histoire", "Science", "Littérature", "Droit", "Philosophie"
  - `file_url` (text) — optional URL to the document file
  - `cover_url` (text) — optional cover image URL
  - `is_free` (boolean, default true) — whether the document is freely accessible
  - `status` (text, default 'published') — published, draft, pending_review
  - `user_id` (uuid, not null, references auth.users, defaults to auth.uid()) — contributor/owner
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

2. Security
- Enable RLS on both tables.
- `profiles`: authenticated users can read all profiles, update only their own.
- `documents`: authenticated users can read published documents, create/update/delete only their own.
- All owner columns default to auth.uid() so inserts succeed without passing user_id.

3. Notes
- This is a multi-user app with sign-in. Policies are scoped to `authenticated`.
- Profile creation is handled via trigger when a user signs up (future migration).
- For now, profiles are created on first sign-up via the frontend.
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  full_name text,
  bio text,
  avatar_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "read_all_profiles" ON profiles;
CREATE POLICY "read_all_profiles" ON profiles FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  author text,
  description text,
  category text,
  file_url text,
  cover_url text,
  is_free boolean NOT NULL DEFAULT true,
  status text NOT NULL DEFAULT 'published',
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE documents ENABLE ROW LEVEL SECURITY;

-- Documents: all authenticated users can read published or free documents
DROP POLICY IF EXISTS "read_published_documents" ON documents;
CREATE POLICY "read_published_documents" ON documents FOR SELECT
  TO authenticated USING (status = 'published' OR user_id = auth.uid());

-- Documents: authenticated users can insert their own
DROP POLICY IF EXISTS "insert_own_documents" ON documents;
CREATE POLICY "insert_own_documents" ON documents FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- Documents: owners can update their own
DROP POLICY IF EXISTS "update_own_documents" ON documents;
CREATE POLICY "update_own_documents" ON documents FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Documents: owners can delete their own
DROP POLICY IF EXISTS "delete_own_documents" ON documents;
CREATE POLICY "delete_own_documents" ON documents FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

-- Index for faster queries
CREATE INDEX IF NOT EXISTS idx_documents_user_id ON documents(user_id);
CREATE INDEX IF NOT EXISTS idx_documents_category ON documents(category);
CREATE INDEX IF NOT EXISTS idx_documents_status ON documents(status);
