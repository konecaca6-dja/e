/*
# Archivo — Profile enhancements: language, favorites, consultation history, avatars

1. Modified Tables
- `profiles`
  - Added `preferred_language` (text, default 'fr') — user's preferred UI language.

2. New Tables
- `favorites`
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to auth.uid(), references auth.users)
  - `document_id` (uuid, not null, references documents)
  - `created_at` (timestamptz, default now())
  - Unique constraint on (user_id, document_id) to prevent duplicate favorites.

- `consultation_history`
  - `id` (uuid, primary key)
  - `user_id` (uuid, not null, defaults to auth.uid(), references auth.users)
  - `document_id` (uuid, not null, references documents)
  - `consulted_at` (timestamptz, default now()) — when the document was viewed.

3. Security
- `profiles`: GRANT UPDATE now includes `preferred_language` (user-editable).
  Role column remains revoked (only admins can change via set_user_role function).
- `favorites`: RLS enabled. Users can CRUD only their own favorites.
- `consultation_history`: RLS enabled. Users can INSERT and SELECT only their own history.
  Users can DELETE their own history (clear history feature).
- `avatars` storage bucket: private bucket for profile photos. Users can upload/read
  only objects in their own folder (uid-prefixed path).

4. Notes
- preferred_language defaults to 'fr' (French) as the app is in French.
- favorites table has ON DELETE CASCADE for both user and document, so deleting
  a document or user cleans up their favorites automatically.
- consultation_history also cascades on user/document deletion.
- Avatar uploads go to `avatars/<uid>/avatar.<ext>` in a private bucket.
*/

-- Add preferred_language to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS preferred_language text NOT NULL DEFAULT 'fr';

-- Re-grant UPDATE to include preferred_language
REVOKE UPDATE ON profiles FROM authenticated;
GRANT UPDATE (username, full_name, first_name, last_name, bio, avatar_url, preferred_language) ON profiles TO authenticated;

-- Create favorites table
CREATE TABLE IF NOT EXISTS favorites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, document_id)
);

ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_favorites" ON favorites;
CREATE POLICY "select_own_favorites" ON favorites FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_favorites" ON favorites;
CREATE POLICY "insert_own_favorites" ON favorites FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_favorites" ON favorites;
CREATE POLICY "delete_own_favorites" ON favorites FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_favorites_user_id ON favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_favorites_document_id ON favorites(document_id);

-- Create consultation_history table
CREATE TABLE IF NOT EXISTS consultation_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  consulted_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE consultation_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_history" ON consultation_history;
CREATE POLICY "select_own_history" ON consultation_history FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_history" ON consultation_history;
CREATE POLICY "insert_own_history" ON consultation_history FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_history" ON consultation_history;
CREATE POLICY "delete_own_history" ON consultation_history FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_history_user_id ON consultation_history(user_id);
CREATE INDEX IF NOT EXISTS idx_history_consulted_at ON consultation_history(consulted_at);

-- Create avatars storage bucket (private)
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies: users can manage only their own avatar folder
DROP POLICY IF EXISTS "avatars_select_own" ON storage.objects;
CREATE POLICY "avatars_select_own" ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "avatars_insert_own" ON storage.objects;
CREATE POLICY "avatars_insert_own" ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "avatars_update_own" ON storage.objects;
CREATE POLICY "avatars_update_own" ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text)
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

DROP POLICY IF EXISTS "avatars_delete_own" ON storage.objects;
CREATE POLICY "avatars_delete_own" ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);
