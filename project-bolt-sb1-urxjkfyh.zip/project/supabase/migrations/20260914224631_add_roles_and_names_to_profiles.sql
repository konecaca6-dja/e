/*
# Archivo — Add roles, names, and privileged role management

1. Modified Tables
- `profiles`
  - Added `role` (text, NOT NULL, default 'utilisateur') — user privilege level.
    Values: 'utilisateur', 'contributeur', 'moderateur', 'administrateur'.
    The 'visiteur' role is implicit for unauthenticated users (no profile row).
  - Added `first_name` (text) — optional given name.
  - Added `last_name` (text) — optional family name.
  - The existing `full_name` column is kept for backward compatibility but new code uses first_name/last_name.

2. Security
- The `role` column is a privilege column: users must NEVER set or change it directly.
  - REVOKE UPDATE (role) FROM authenticated — column-level privilege narrows what
    the UPDATE policy allows the owner to change.
  - A SECURITY DEFINER function `set_user_role` lets admins change roles;
    it derives the caller from auth.uid() and checks admin privilege internally.
- `first_name` and `last_name` remain user-editable (included in the GRANT UPDATE list).

3. Functions
- `set_user_role(target_user uuid, new_role text)` — SECURITY DEFINER.
  Only administrators (role = 'administrateur') can call it.
  Validates that new_role is one of the allowed values.
  REVOKE EXECUTE FROM anon; GRANT EXECUTE TO authenticated.

4. Notes
- Password hashing is handled by Supabase Auth (bcrypt) — no custom password storage.
- Email verification and password reset use Supabase Auth built-in flows.
- The first registered user can be promoted to administrateur via execute_sql or
  a future admin panel. For now, all new users default to 'utilisateur'.
*/

-- Add role, first_name, last_name columns to profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS role text NOT NULL DEFAULT 'utilisateur';
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS first_name text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS last_name text;

-- Add constraint to enforce valid roles
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.check_constraints
    WHERE constraint_name = 'profiles_role_valid'
  ) THEN
    ALTER TABLE profiles ADD CONSTRAINT profiles_role_valid
      CHECK (role IN ('utilisateur', 'contributeur', 'moderateur', 'administrateur'));
  END IF;
END $$;

-- Revoke UPDATE on the role column so users cannot change their own role
-- Column-level privileges are checked BEFORE row-level policies
REVOKE UPDATE ON profiles FROM authenticated;
GRANT UPDATE (username, full_name, first_name, last_name, bio, avatar_url) ON profiles TO authenticated;

-- SECURITY DEFINER function: only admins can change a user's role
CREATE OR REPLACE FUNCTION set_user_role(p_target_user uuid, p_new_role text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  -- Authorize the CALLER (derived from session, not a parameter)
  IF NOT EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid() AND role = 'administrateur'
  ) THEN
    RAISE EXCEPTION 'Not authorized to change user roles';
  END IF;

  -- Validate the new role value
  IF p_new_role NOT IN ('utilisateur', 'contributeur', 'moderateur', 'administrateur') THEN
    RAISE EXCEPTION 'Invalid role value';
  END IF;

  -- Apply the change
  UPDATE profiles SET role = p_new_role WHERE id = p_target_user;
END;
$$;

REVOKE EXECUTE ON FUNCTION set_user_role(uuid, text) FROM anon;
GRANT EXECUTE ON FUNCTION set_user_role(uuid, text) TO authenticated;

-- Index for faster role-based queries
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
